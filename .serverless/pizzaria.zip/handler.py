import json
from pizzaEvents import PizzaEvents

events = PizzaEvents

def recordAllEvents():
    events.putAllEvents
